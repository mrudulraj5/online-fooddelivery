export interface Food{
    description: string;
    image: string;
    mrpPrice : number;
    foodId : number;
    foodname :string;
    quantity: number;
    category: string;
}
